export const defaults = {
  brand:'RA CALÇADOS', whatsapp:'5516994623076', instagram:'',
  theme:{primary:'#e63946',dark:'#101521',surface:'#f4f6fa'},
  pages:[
    {id:'inicio',name:'Início',sections:[
      {id:'hero',type:'hero',title:'O seu próximo passo começa aqui.',subtitle:'Tênis, chinelos e estilo para todos os momentos.',button:'Ver produtos',image:'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1500&q=85'},
      {id:'beneficios',type:'benefits',title:'Por que comprar na RA CALÇADOS?',items:['Atendimento pelo WhatsApp','Produtos selecionados','Compra prática e segura']},
      {id:'destaques',type:'products',title:'Escolha seu favorito',subtitle:'Conheça nossa coleção.'},
      {id:'chamada',type:'banner',title:'Conforto que acompanha você',subtitle:'Encontre o modelo ideal para o seu dia a dia.',button:'Falar no WhatsApp',image:'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=1500&q=85'}
    ]},
    {id:'colecao',name:'Coleção',sections:[{id:'produtos',type:'products',title:'Todos os calçados',subtitle:'Escolha seu novo modelo favorito.'}]},
    {id:'sobre',name:'Sobre nós',sections:[{id:'sobrenos',type:'text',title:'Sobre a RA CALÇADOS',subtitle:'Calçados com estilo, conforto e atendimento de verdade. Fale com nossa equipe e conheça nossa coleção.'}]}
  ],
  products:[
    {id:'p1',name:'Tênis Esportivo RA',price:149.9,category:'Tênis',sizes:'38,39,40,41,42',image:'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80',active:true},
    {id:'p2',name:'Tênis Casual Urbano',price:179.9,category:'Tênis',sizes:'37,38,39,40,41',image:'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&q=80',active:true},
    {id:'p3',name:'Chinelo Conforto',price:59.9,category:'Chinelos',sizes:'35,36,37,38,39,40',image:'https://images.unsplash.com/photo-1603487742131-4160ec999306?w=800&q=80',active:true},
    {id:'p4',name:'Tênis Branco Clássico',price:169.9,category:'Tênis',sizes:'38,39,40,41,42',image:'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=800&q=80',active:true}
  ],
  notice:'Catálogo demonstrativo: preços e fotos de exemplo. Confirme disponibilidade com a loja.',
  updatedAt:null
};
